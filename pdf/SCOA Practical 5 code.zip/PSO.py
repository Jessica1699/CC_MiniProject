import random
import numpy as np 

W = 0.5
c1 = 0.8
c2 = 0.9 

n_iterations = int(input("Inform the number of iterations: "))
target_error = float(input("Inform the target error: "))
n_particles = int(input("Inform the number of particles: "))

class Particle():
    def __init__(self):
        self.position = np.array([(-1) ** (bool(random.getrandbits(1))) * random.random()*50, (-1)**(bool(random.getrandbits(1))) * random.random()*50])
        self.pbest_position = self.position
        self.pbest_value = float('inf')
        self.velocity = np.array([0,0])

    def __str__(self):
        print("I am at ", self.position, " meu pbest is ", self.pbest_position)
    
    def move(self):
        self.position = self.position + self.velocity


class Space():

    def __init__(self, target, target_error, n_particles):
        self.target = target
        self.target_error = target_error
        self.n_particles = n_particles
        self.particles = []
        self.gbest_value = float('inf')
        self.gbest_position = np.array([random.random()*50, random.random()*50])

    def print_particles(self):
        for particle in self.particles:
            particle.__str__()
   
    def fitness(self, particle):
        return particle.position[0] ** 2 + particle.position[1] ** 2 + 1

    def set_pbest(self):
        for particle in self.particles:
            fitness_cadidate = self.fitness(particle)
            if(particle.pbest_value > fitness_cadidate):
                particle.pbest_value = fitness_cadidate
                particle.pbest_position = particle.position
            

    def set_gbest(self):
        for particle in self.particles:
            best_fitness_cadidate = self.fitness(particle)
            if(self.gbest_value > best_fitness_cadidate):
                self.gbest_value = best_fitness_cadidate
                self.gbest_position = particle.position

    def move_particles(self):
        for particle in self.particles:
            global W
            new_velocity = (W*particle.velocity) + (c1*random.random()) * (particle.pbest_position - particle.position) + \
                            (random.random()*c2) * (self.gbest_position - particle.position)
            particle.velocity = new_velocity
            particle.move()
            

search_space = Space(1, target_error, n_particles)
particles_vector = [Particle() for _ in range(search_space.n_particles)]
search_space.particles = particles_vector
search_space.print_particles()

iteration = 0
while(iteration < n_iterations):
    search_space.set_pbest()    
    search_space.set_gbest()

    if(abs(search_space.gbest_value - search_space.target) <= search_space.target_error):
        break

    search_space.move_particles()
    iteration += 1
    
print("The best solution is: ", search_space.gbest_position, " in n_iterations: ", iteration)


"""Output

Inform the number of iterations: 50
Inform the target error: 1e-6
Inform the number of particles: 30
('I am at ', array([26.03013598, 12.57463712]), ' meu pbest is ', array([26.03013598, 12.57463712]))
('I am at ', array([22.97851621, 40.36178045]), ' meu pbest is ', array([22.97851621, 40.36178045]))
('I am at ', array([32.51424377, -2.02345456]), ' meu pbest is ', array([32.51424377, -2.02345456]))
('I am at ', array([-34.51988431,  42.88551113]), ' meu pbest is ', array([-34.51988431,  42.88551113]))
('I am at ', array([14.85075289,  3.21200789]), ' meu pbest is ', array([14.85075289,  3.21200789]))
('I am at ', array([-20.50294348, -41.68056672]), ' meu pbest is ', array([-20.50294348, -41.68056672]))
('I am at ', array([-42.71962786,  28.67609299]), ' meu pbest is ', array([-42.71962786,  28.67609299]))
('I am at ', array([-10.46503002, -41.84461274]), ' meu pbest is ', array([-10.46503002, -41.84461274]))
('I am at ', array([-10.21438885, -48.12384232]), ' meu pbest is ', array([-10.21438885, -48.12384232]))
('I am at ', array([41.92298384, 36.07670221]), ' meu pbest is ', array([41.92298384, 36.07670221]))
('I am at ', array([ 24.11942874, -36.9674037 ]), ' meu pbest is ', array([ 24.11942874, -36.9674037 ]))
('I am at ', array([-16.67011438,   4.56182882]), ' meu pbest is ', array([-16.67011438,   4.56182882]))
('I am at ', array([16.78716099, 22.25087838]), ' meu pbest is ', array([16.78716099, 22.25087838]))
('I am at ', array([ 47.22682108, -24.87047403]), ' meu pbest is ', array([ 47.22682108, -24.87047403]))
('I am at ', array([-44.5329639 ,   7.85217129]), ' meu pbest is ', array([-44.5329639 ,   7.85217129]))
('I am at ', array([17.01813457, 12.96793506]), ' meu pbest is ', array([17.01813457, 12.96793506]))
('I am at ', array([ -8.21852346, -42.12597023]), ' meu pbest is ', array([ -8.21852346, -42.12597023]))
('I am at ', array([20.30715334, 19.53872857]), ' meu pbest is ', array([20.30715334, 19.53872857]))
('I am at ', array([-23.82376912, -14.97930604]), ' meu pbest is ', array([-23.82376912, -14.97930604]))
('I am at ', array([ 12.3290151 , -36.65363899]), ' meu pbest is ', array([ 12.3290151 , -36.65363899]))
('I am at ', array([ 40.27064221, -28.49215403]), ' meu pbest is ', array([ 40.27064221, -28.49215403]))
('I am at ', array([-18.95016009, -45.23219435]), ' meu pbest is ', array([-18.95016009, -45.23219435]))
('I am at ', array([ 42.6041078 , -33.17262849]), ' meu pbest is ', array([ 42.6041078 , -33.17262849]))
('I am at ', array([ 24.34848845, -21.02340442]), ' meu pbest is ', array([ 24.34848845, -21.02340442]))
('I am at ', array([-27.60906761,  13.05501498]), ' meu pbest is ', array([-27.60906761,  13.05501498]))
('I am at ', array([-11.45408237,  38.51154997]), ' meu pbest is ', array([-11.45408237,  38.51154997]))
('I am at ', array([-13.28337231,  28.91634015]), ' meu pbest is ', array([-13.28337231,  28.91634015]))
('I am at ', array([49.1655284 ,  5.26419305]), ' meu pbest is ', array([49.1655284 ,  5.26419305]))
('I am at ', array([  3.84049551, -10.65639115]), ' meu pbest is ', array([  3.84049551, -10.65639115]))
('I am at ', array([-43.40268964, -26.94737507]), ' meu pbest is ', array([-43.40268964, -26.94737507]))
('The best solution is: ', array([ 8.48326925e-05, -3.96916568e-04]), ' in n_iterations: ', 24)

"""

