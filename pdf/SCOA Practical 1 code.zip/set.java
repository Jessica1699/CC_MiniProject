
public class set {

	String label;
	double value;
}
